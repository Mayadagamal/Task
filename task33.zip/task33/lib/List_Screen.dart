import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'ProudectData.dart';

class ListScreen extends StatefulWidget {
  const ListScreen({super.key});
  @override
  State<ListScreen> createState() => _ListScreenState();
}
class _ListScreenState extends State<ListScreen> {
  Future<List<ProductData>> getData() async {
    final res = await http.get(Uri.parse('https://dummyjson.com/products'));
    List<ProductData> dataA = [];
    if (res.statusCode == 200) {
      Map<String, dynamic> responseData = jsonDecode(res.body);
      for (var item in responseData['products']) {
        dataA.add(ProductData.fromJson(item));
      }
    }
    return dataA;
  }
  List<ProductData> myList = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    Future.delayed(
      Duration.zero,
          () async {
        var data = await getData();
        setState(() {
          myList = data;
          isLoading= false;
        });
      },
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title:const Text('New product')
      ),
      body:isLoading
          ? const Center(
          child:CircularProgressIndicator())
          :SafeArea(
        child:GridView.builder(
          itemCount: myList.length,
          itemBuilder: (context,index){
            return Container(
              height: MediaQuery.of(context).size.height * 0.2,
              width: MediaQuery.of(context).size.width * 0.4,
              decoration:  BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(30),
                image: DecorationImage(
                  image: NetworkImage(myList[index].thumbnailUrl),
                  fit: BoxFit.fill,
                ),
              ),
              alignment: Alignment.bottomCenter,
              margin:  const EdgeInsets.all(10),
              child: Container(
                width: double.infinity,
                height: 50,
                decoration: const BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30))),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Expanded(
                      child: Text(
                        myList[index].name,
                      ),
                    ),
                    Text(

                      '${myList[index].price.toString()} EGP',
                      style: const TextStyle(
                        fontSize: 20,
                        backgroundColor: Colors.black54,

                      ),
                    ),
                  ],
                ),
              ),
            );
          },
          gridDelegate:  const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2),
        ),
      ),
    );
  }
}