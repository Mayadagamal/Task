
class ProductData {
  final String name;
  final String description;
  final double price;
  final String thumbnailUrl;

  ProductData({
    required this.name,
    required this.description,
    required this.price,
    required this.thumbnailUrl,
  });

  factory ProductData.fromJson(Map<String, dynamic> json) {
    return ProductData(
      name: json['name'] ?? '',
      description: json['description'] ?? '',
      price: (json['price'] ?? 0.0).toDouble(),
      thumbnailUrl: json['thumbnail'] ?? '',
    );
  }
}
