package com.example.task33

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
