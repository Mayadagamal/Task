package com.example.mayada22

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
